# 索引范围与证据口径

SOURCE_MAP.csv共600个相关源码/配置/测试/构建入口，提供实际路径、行数、hash与顶层符号。自动索引不代表每个文件逐行人工审阅；因果链审阅与当前已发现问题在任务包、架构和TAKEOVER_REVIEW中定位。

层级文件数：
- adapters：7
- agent1：9
- agent2：17
- agent3：20
- agent5：4
- api：10
- application：9
- artifacts：1
- build_tools：22
- canonical：6
- configuration：238
- contracts：5
- events：6
- frontend：64
- graph：6
- legacy：7
- ports：3
- protocol_workflow：1
- qc：3
- registries：8
- runtime：11
- storage：3
- terminology：2
- tests：138

此包不复制完整仓库、运行数据库、共享服务配置、raw session日志或含key原交接。源模板等外部资料通过AUTHORITY_MANIFEST定位/hash验证。当前43个未提交代码文件的内容在source_overlay.tar.gz；建议同目录fork以保留完整现有依赖与历史。

孤立Office fixture入口（历史诊断，不是完整E2E）：/Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/runs/requirements_v2_20260919/t17_round11/office_browser_fixture.py。启动会写其指定隔离合成数据库；后续F12需要使用新的case目录并保留旧工件，不能盲目沿用旧seed.json当新验收。

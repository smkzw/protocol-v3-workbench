import { useEffect, useRef, useState } from 'react';
import './GenOfficeFrame.css';

async function bundleInstalled() {
  try {
    const response = await fetch('/genoffice/index.html', { method: 'HEAD' });
    return response.ok;
  } catch {
    return false;
  }
}

/**
 * One-instance-one-iframe GenOffice docs runtime (T10/P3; audit G1 rework).
 *
 * 打开来源 = 当前Office工作稿：已有Office快照时从最新快照初始化（唯一标记、
 * 表格、页眉修改在关闭重开后保留）；尚无快照时才从语义稿导出初始化。下载
 * 链接与打开来源同源，不再固定指向语义稿（F01）。一次会话冻结一个iframe：
 * 宿主状态刷新不重建运行中的编辑器（F03）；关闭前确认，避免无声丢弃未保存
 * 修改。每次保存携带打开时的 artifact revision 做条件写，双窗口不会互相
 * 静默覆盖（F04）；研究基线取工作稿绑定的版本，不再被贴上当前版本（F05）。
 */
export function GenOfficeFrame({ projectId, studyDefinitionId, actorId, savedDocument, onClose, onSessionChange, onNavigationGuardChange, api }) {
  const [open, setOpen] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [focused, setFocused] = useState(false);
  const [notice, setNotice] = useState('');
  const [confirmingClose, setConfirmingClose] = useState(false);
  // 一次会话冻结一次打开参数：savedDocument 在编辑器打开期间变化只更新外层
  // 展示，不重建 iframe（F03）。
  const [session, setSession] = useState(null);
  const iframeRef = useRef(null);
  const initialOpen = useRef(false);
  const [head, setHead] = useState(null);
  const [headReady, setHeadReady] = useState(false);
  const [headReload, setHeadReload] = useState(0);
  const [backupUrl, setBackupUrl] = useState(null);
  const backupRef = useRef(null);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [history, setHistory] = useState(null);
  const [historyError, setHistoryError] = useState('');

  const semanticDocUrl = `/api/projects/${encodeURIComponent(projectId)}/protocol-workflow/study-definitions/`
    + `${encodeURIComponent(studyDefinitionId)}/manuscript-draft/export/docx`;
  const snapshotsBase = `/api/projects/${encodeURIComponent(projectId)}/protocol-workflow/study-definitions/`
    + `${encodeURIComponent(studyDefinitionId)}/manuscript-draft/office-draft/snapshots`;

  function snapshotUrl(receipt) {
    return `${snapshotsBase}/${encodeURIComponent(receipt.operation_id)}/content`;
  }

  useEffect(() => {
    let active = true;
    setHeadReady(false);
    Promise.resolve().then(() => api.latestOfficeSnapshot(projectId, studyDefinitionId))
      .then(value => { if (active) { setHead(value); setHeadReady(true); } })
      .catch(error => {
        if (!active) return;
        if (error?.status === 404) { setHead(null); setHeadReady(true); }
        else setNotice('暂时无法读取已保存工作稿，请重新打开页面后再试。');
      });
    return () => { active = false; };
  }, [api, projectId, studyDefinitionId, headReload]);

  useEffect(() => {
    function receiveSave(event) {
      if (event.origin !== window.location.origin || event.source !== iframeRef.current?.contentWindow
        ) return;
      if (event.data?.type === 'protocol-office:dirty') { setDirty(Boolean(event.data.dirty)); return; }
      if (event.data?.type === 'protocol-office:save-failed') {
        if (event.data.latest_snapshot?.operation_id) setHead(event.data.latest_snapshot);
        setNotice(`${event.data.error || '本次保存未完成。'} 本次修改尚未确认保存；请先下载未保存修改，再关闭编辑器核对最新版本。`);
        if (event.data.data) {
          if (backupRef.current) URL.revokeObjectURL(backupRef.current);
          backupRef.current = URL.createObjectURL(new Blob([event.data.data], { type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' }));
          setBackupUrl(backupRef.current);
        }
        return;
      }
      if (event.data?.type !== 'protocol-office:saved') return;
      const receipt = event.data.receipt;
      if (!receipt?.operation_id || !receipt?.artifact_revision) return;
      setHead(receipt);
      setHeadReady(true);
      setNotice(`修改已保存，第 ${receipt.artifact_revision} 版；可下载当前工作稿。`);
    }
    window.addEventListener('message', receiveSave);
    return () => { window.removeEventListener('message', receiveSave); if (backupRef.current) URL.revokeObjectURL(backupRef.current); };
  }, []);

  useEffect(() => {
    onNavigationGuardChange?.(dirty ? { dirty: true, sectionTitle: '当前 Word 工作稿', hasRecoveryDraft: false } : null);
    if (!dirty) return undefined;
    const beforeUnload = event => { event.preventDefault(); event.returnValue = ''; };
    window.addEventListener('beforeunload', beforeUnload);
    return () => { window.removeEventListener('beforeunload', beforeUnload); onNavigationGuardChange?.(null); };
  }, [dirty, onNavigationGuardChange]);

  useEffect(() => {
    if (!historyOpen) return undefined;
    const controller = new AbortController();
    setHistory(null); setHistoryError('');
    Promise.resolve().then(() => api.officeSnapshotHistory(projectId, studyDefinitionId, { signal: controller.signal }))
      .then(result => {
        if (!Array.isArray(result?.snapshots)) throw new Error('unreadable history');
        if (!controller.signal.aborted) setHistory(result.snapshots);
      }).catch(() => {
        if (!controller.signal.aborted) setHistoryError('暂时无法读取历史版本，当前编辑内容不受影响。');
      });
    return () => controller.abort();
  }, [historyOpen, head?.operation_id, api, projectId, studyDefinitionId]);

  useEffect(() => {
    if (!focused) return undefined;
    const escape = event => { if (event.key === 'Escape') setFocused(false); };
    window.addEventListener('keydown', escape);
    return () => window.removeEventListener('keydown', escape);
  }, [focused]);

  function belongsToOlderDraft(receipt) {
    if (!receipt) return false;
    if (receipt.document_sha256) return receipt.document_sha256 !== savedDocument.document_sha256;
    return receipt.document_revision != null && receipt.document_revision !== savedDocument.document?.revision;
  }

  async function beginSession(mode = 'current') {
    if (!(await bundleInstalled())) {
      setNotice('文档编辑器暂不可用，已保存工作稿仍可下载。');
      return;
    }
    const revision = savedDocument.document?.revision ?? 1;
    let studySha = savedDocument.document?.study_definition_sha256 || '';
    let docUrl = semanticDocUrl;
    let officeRevision = null;
    let baseArtifactRevision = 0;
    let openingCandidate = false;
    let continuingExisting = false;
    try {
      const latest = await api?.latestOfficeSnapshot?.(projectId, studyDefinitionId);
      if (latest?.operation_id && latest?.artifact_revision) {
        setHead(latest);
        baseArtifactRevision = latest.artifact_revision;
        if (belongsToOlderDraft(latest)) {
          if (mode !== 'candidate' && mode !== 'existing') {
            setNotice('本次新起草候选尚未替换现有工作稿。可继续编辑已保存的 Word，或选择新候选。');
            return;
          }
          openingCandidate = mode === 'candidate';
          continuingExisting = mode === 'existing';
        }
        if (!openingCandidate) {
          docUrl = `${snapshotsBase}/${encodeURIComponent(latest.operation_id)}/content`;
          officeRevision = latest.artifact_revision;
          studySha = latest.study_revision_sha256 || studySha;
        }
      }
    } catch (error) {
      if (error?.status !== 404) {
        setNotice('无法核对最新工作稿，暂未打开编辑器。请重试。');
        return;
      }
    }
    const query = new URLSearchParams({
      docUrl,
      docName: officeRevision ? `研究方案工作稿_编辑版${officeRevision}.docx` : `研究方案工作稿_初稿${revision}.docx`,
      saveUrl: `${snapshotsBase}`,
      rev: String(revision),
      sha: savedDocument.document_sha256 || '',
      actor: actorId || 'medical_manager',
      openedStudySha: studySha,
      baseArtifactRevision: String(baseArtifactRevision),
    });
    setSession({ query: query.toString(), docUrl, revision, officeRevision, studySha, openingCandidate });
    setOpen(true);
    onSessionChange?.(true);
    setNotice(openingCandidate ? '正在编辑新起草候选；保存后成为当前工作稿，原稿保留。'
      : continuingExisting ? '正在编辑已保存的 Word；新起草候选尚未采用。' : '');

  }

  useEffect(() => {
    if (!headReady || initialOpen.current) return;
    initialOpen.current = true;
    void beginSession();
  }, [headReady]);

  function requestClose() {
    // Reuse the renderer close-check state; only unsaved changes need confirmation.
    if (dirty && !confirmingClose) {
      setConfirmingClose(true);
      return;
    }
    setConfirmingClose(false);
    setDirty(false);
    setOpen(false);
    setFocused(false);
    onSessionChange?.(false);
    setSession(null);

    onClose?.();
  }

  const params = session?.query ?? null;

  if (!savedDocument) return null;
  const currentUrl = head?.operation_id ? snapshotUrl(head) : semanticDocUrl;
  const hasNewCandidate = belongsToOlderDraft(head);
  return <section className={open ? `gz-office-frame${focused ? ' gz-office-frame--focus' : ''}` : 'gz-office-entry'} aria-label="文档编辑与下载">
    <header>
      <strong>{head ? `已保存工作稿 · 第 ${head.artifact_revision} 版` : '研究方案工作稿'}</strong>
      <div>
        <button type="button" aria-expanded={historyOpen} onClick={() => setHistoryOpen(value => !value)}>Word 版本记录</button>
        {open && <button type="button" aria-pressed={focused} onClick={() => setFocused(value => !value)}>{focused ? '返回研究工作台' : '专注编辑'}</button>}
        {headReady && <a href={currentUrl} download={head ? `研究方案工作稿_编辑版${head.artifact_revision}.docx` : `研究方案工作稿_初稿${savedDocument.document.revision}.docx`}>下载当前 Word 工作稿</a>}
        {!open ? <button type="button" className="kz-manuscript-primary" disabled={!headReady}
          onClick={() => beginSession(hasNewCandidate ? 'candidate' : 'current')}>{hasNewCandidate ? '编辑本次新起草候选' : '打开文档编辑器'}</button> : <button type="button" onClick={requestClose}>
          {confirmingClose ? '确认关闭（未保存修改将丢失）' : '关闭编辑器'}
        </button>}
        {!open && headReady && hasNewCandidate && <button type="button" onClick={() => beginSession('existing')}>继续编辑已保存的 Word</button>}
      </div>
    </header>
    {historyOpen && <div className="gz-office-history" aria-label="已保存的Word版本">
      {historyError ? <p role="alert">{historyError}</p> : history === null ? <p role="status">正在读取版本记录…</p>
        : history.length === 0 ? <p>首次保存后，版本会出现在这里。</p>
          : <ul>{history.map(version => <li key={version.operation_id}>
            <span>第 {version.artifact_revision} 版{version.operation_id === head?.operation_id ? ' · 当前已保存版本' : ''}</span>
            <time dateTime={version.saved_at}>{version.saved_at ? new Date(version.saved_at).toLocaleString('zh-CN') : ''}</time>
            <a href={snapshotUrl(version)} download={`研究方案工作稿_编辑版${version.artifact_revision}.docx`}>下载第 {version.artifact_revision} 版</a>
          </li>)}</ul>}
    </div>}
    {notice && <p role="status">{notice}</p>}
    {!headReady && notice && <button type="button" onClick={() => { setNotice(''); setHeadReload(value => value + 1); }}>重新读取已保存稿</button>}
    {backupUrl && <a href={backupUrl} download="研究方案_未保存修改.docx">下载未保存修改（本地备份）</a>}
    {open && params && <iframe ref={iframeRef} title="GenOffice文档编辑器"
      src={`/genoffice/index.html?${params}`} />}
  </section>;
}

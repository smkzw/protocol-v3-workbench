**审阅结论：REVISE。指定双入口尚不能据源码认定已贯通同一条实际 Word 工作稿链。** 当前存在两套生成、正文存储及导出路径；GenOffice 下游已有实质实现，主要缺口在入口承接、候选接收及正文所有权统一，不能通过再建一套正文库解决。

本轮仅执行文件读取、源码搜索、Git 状态及 SHA-256 核对。开始与结束 HEAD 均为 `acf6d8341563d56946f934dfdac65c76997e36e3`；所查主链源码未显示相对 HEAD 的工作区差异。工作区其他未提交内容未修改。未写任何文件，未运行测试、服务、浏览器、模型或桌面 Word，未读取指定禁止文件、密钥或运行时秘密配置，未派发下级。**下述“已接线”仅指源码调用关系成立，不是集成 PASS。**

**一、两个用户入口与实际下游**

先区分三个容易混淆的概念：

- “导入方案摘要／从零开始”是 App 新建项目弹窗的两个真实入口。
- `AuthoringCandidatePackagePanel` 是研究设计预填候选界面，不是 Word 正文候选接收器。
- `WritingPage → full-drafts` 与 `ProtocolIntakeWorkspace → manuscript-draft` 是不同路径，由前端 feature flag 分流。

| 环节 | A：导入方案摘要 | B：从零开始 | 接线判断 |
|---|---|---|---|
| 用户入口 | App 弹窗选择“导入方案摘要”，挂载 `MedicalWritingSynopsisProjectIntake`。[App:1474–1489][app-entry] | 同一弹窗选择“从零开始”，填写药物、适应症、分期；提交 `/api/projects`。[App:1297–1333、1493–1501][app-create] | 两入口真实存在 |
| 上传／创建 endpoint | 组件 POST `/api/medical-writing/project-intake/synopsis`，轮询后预填 framing、PICOS、摘要；确认 POST `/synopsis/confirm`。[Intake:250–261、283–308、389–417][intake] | `/api/projects` 创建项目，同时创建 `guided_greenfield` authoring journey。[main:3910–3947][project-create] | 各自有后端调用 |
| service／研究定义 | confirm 路由调用 `attach_synopsis_import()`、`confirm_synopsis_import()`，完整字段进一步 `commit_stage()`。[main:7464–7533][synopsis-confirm] | Setup 调用 `/prefill-package/generate`、`/adopt`、`/adopt-composite`，再提交 stages；候选面板通过父组件回调完成写入。[Setup:1121、1183、1292–1304、2026–2035][setup]；[Panel:911–920、1025–1028][package-panel] | 两者在 **authoring journey 路径**汇合 |
| 持久研究状态 | journey 内构建 `study_definition`；更新写入 `medical_writing_authoring_journeys.payload_json`。[Journey:828–842、5989–6033][journey] | 同一 journey 存储合同；不是仅前端预填 | 已有持久化，但不能直接等同 protocol-workflow 的 StudyDefinition |
| 建项后导航 | `onCreated` 只向 App 传 project、entry mode；最终 `handleProjectCreated(project)` 只切换项目及 writing 页面。[App:1485–1488、15539–15545][project-navigation] | 同左 | **没有在此承接返回的 journey／研究定义／seed 身份** |
| 页面选择 | `VITE_PROTOCOL_V3_WORKFLOW_ENABLED` 为 `1/true` 时进入 `ProtocolIntakeWorkspace`；否则进入 `WritingPage`。[App:16156–16170][app-switch] | 同左 | **这是分流，不是转换适配器** |

从这里开始，应分别记录下游，不能把它们拼成一条已经存在的链：

| 环节 | `WritingPage / full-drafts` 路径 | `ProtocolIntakeWorkspace / manuscript-draft` 路径 |
|---|---|---|
| 研究准备 | Setup 使用 journey 研究绑定 POST `/medical-writing/greenfield-document`；后端要求写作准入和匹配研究定义。[Setup:2326–2349][setup-create]；[main:9109–9140][greenfield] | `ProtocolSourceIntake` 提交用户说明及所选 `sourceArtifactIds`；`research-intake` 调用 `prepare_current_seed()`、coordinator。[SourceIntake:456–458][source-intake]；[research_intake:44–59][research-intake] |
| StudyDefinition writer | 消费 journey 的定义 ID/revision/hash | `design.py` 由 seed 创建 `study:v3:…`；调用 `application_service.create_study_definition()`。初始事实为 `research.input_context`，后续由设计确认写入。[design:144–178][design]；[research_context:9–27][research-context] |
| AI 候选 | App POST `/medical-writing/full-drafts` → `MedicalWritingFullDraftService.submit_durable()`；工件根为 `RUNTIME_DIR/medical_writing_full_drafts`。[App:10445–10458][full-ui]；[main:2567–2570、7801–7822][full-service] | `ManuscriptWorkspace` 调用 prepare/start/recover，读取章节候选；后端由 manuscript coordinator 管理。[Workspace:265–275][manuscript-workspace]；[composition:410–421][composition] |
| 候选接收／working copy | `/full-drafts/{job}/adopt` 调用 `repo.save_working_copy()`，逐章写入旧正文存储。[full_draft:1300–1402][full-adopt] | `/manuscript-draft/save` 调用 `documents.save()`，组装 `SemanticDocumentRevision`，在现有 UoW 内条件写入并记录事件。[api:443–464][manuscript-save]；[documents:82–121][documents] |
| 进入 Office | **未找到把上述章节 working copy 转交 ManuscriptDocumentService／GenOffice 的调用。** App 采纳成功后仅刷新旧 document session、working copy、冻结及质量状态。[App:10483–10493][full-ui] | 保存成功后挂载 `GenOfficeFrame`；首次候选 DOCX 来自 `/candidate/docx`，已有 Office 稿读取具体 snapshot content。[Workspace:548–552][manuscript-view]；[Frame:218–269][office-open] |
| 保存 Word | 上述 adopt 不保存 Office DOCX | iframe bridge POST `/office-draft/snapshots`；后端检查 Office 基础版本、语义来源版本，持久化不可变 DOCX 和事件。[bridge:85–127][bridge]；[documents:738–820][office-store] |
| 核对 | 旧路径刷新自身 study consistency／content quality／freeze readiness；**不是当前 Office 字节核对** | `/office-draft/reconciliation` 读取最新 DOCX 字节并投影；失败不阻止保存下载。[api:672–689][office-api]；[documents:878–898][office-reconcile] |
| 下载 | `/medical-writing/document-exports` → 旧文档组装导出器 → download。[main:9819–9845、9958–9977][legacy-export] | Frame 下载具体 Office 操作版本；`/export/docx` 有 Office head 时返回其字节，无 head 才生成语义候选。[Frame:381–403][office-ui]；[api:195–248][manuscript-export] |
| 总体状态 | 可以到旧路径 DOCX 导出，**未贯通 GenOffice 当前稿** | Office 下游源码连通；**未证明 App 双入口既有成果自动进入此链** |

新工作台本身支持“所选文件＋说明”及“仅说明”共用 research-intake，因此已有可复用的统一入口能力。但 `ProtocolIntakeWorkspace` 初始化 brief/run 来自自己的 localStorage，调用链没有读取已完成的 authoring journey；`StudyContextWorkspace` 又通过另一套研究列表／context 接口接续研究。[IntakeWorkspace:27–34、98–115、235–248][protocol-intake]；[StudyContext:64–85][study-context]

因此，不能用“新工作台也能上传文件”证明旧摘要入口的**已提取内容、来源身份及已确认决定**已经被承接。

**二、正文所有权与最小连接路线**

`medical_writing_full_draft.repo.working_copy()` 不是 `ManuscriptDocumentService` 的别名：

| 对象 | 实际存储及身份 | 当前用途 |
|---|---|---|
| 旧章节 working copy | `MedicalWritingRuntimeRepository` → `SqliteRuntimeStore` → `medical_writing_working_copies`；按 project/document/section 定位，独立 revision | 旧编辑、采纳、冻结及组装导出 |
| manuscript 语义文档 | `semantic_document_repository`；`manuscript:`＋project/study 哈希；UoW/CAS＋事件 | AI 起草候选、初次 DOCX 构造及来源记录 |
| Office 当前稿 | `office-draft:{project}:{study}` 内容寻址制品；`manuscript_office_snapshot.v1` 事件确定当前版本 | 实际 DOCX 编辑、保存、历史下载、字节核对 |

证据：[repository:893–935、960–1018、1099–1112][working-repo]；[SQLite:9130–9167、9222–9232、9289、10772–10788][working-store]；[documents:17–57、82–121][documents]；[Office:784–811][office-store]。

**确有两套可写正文模型并存；但本轮没有证据证明同一运行实例已同时开放二者，或已发生双向覆盖。** UI feature flag 分流也不能充当正文所有权合同。

新 manuscript 路径内部已经采取正确方向：AI 起草依据只读，Office 保存后下载实际 Word，新语义候选须显式选择。这种“候选＋当前文档”的分工本身不等于第二正文主库，应保留。[Workspace:560–569][manuscript-view]；[Frame:237–250、272–273][office-open]

建议 owner 采用以下最小接线：

1. **将现有 manuscript／Office 链确定为用户当前稿主路径。** 保留语义候选、来源及历史，不新增正文表或另一套文档状态机。
2. 在双入口完成处，补一个有版本绑定的交接：project、来源制品身份、已确认字段及确认来源、目标 study ID。复用现有 StudyDefinition writer；不要仅因旧字段存在就全部升级为新链“已确认”事实，也不要再次让用户上传同一文件。
3. `full-draft` 保留为候选生产者。增加薄适配，将其章节、来源及缺口映射为现有 manuscript 接收合同，再由同一文档服务创建候选版本。**不能先写旧 working copy，再长期同步另一正文库。**
4. 已有人工 Word 时，新输出只成为候选；继续沿用 GenOffice 的“继续旧稿／选择新候选”机制及 Office base revision。后续局部补写也不得隐式整稿替换。
5. 旧 working copy 与旧导出保留历史读取及必要兼容；对转入新主路径的项目明确写入归属。不要泛化删除 legacy，也不要把旧导出重新命名为“当前 Word”。

专家 F04 的事务疑问可进一步收窄：真实 `commit_medical_writing_working_copy_save()` 每章自行连接、`BEGIN IMMEDIATE` 并 `commit()`；`adopt()` 循环逐章调用。因此源码支持“后章冲突时前章已提交”，未见覆盖整个 adopt 的统一事务。**这是源码控制流结论，不是本轮故障注入结果。**

**三、renderer 的真实本地指向**

本轮核验到：

| 项目 | 真实指向／状态 |
|---|---|
| 上游本地仓库 | [genoffice-upstream](/Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/genoffice-upstream) |
| 上游 HEAD | `316ded6f0a39235fec8d21c068d8a0766ee6172b` |
| 上游工作区 | `App.tsx`、`sources.ts`、`parse-props.ts`、`types.ts`、lockfile 等有修改；`protocol-office.ts` 为未跟踪文件 |
| 构建入口 | [build_genoffice_renderer.sh:7–18][renderer-build]：默认取工作台同级 `genoffice-upstream`，可被 `GENOFFICE_ROOT` 覆盖；在 `apps/docs` 使用 `vite.renderer.config.ts` 构建 |
| 构建输出 | 上游 `apps/docs/src/renderer/dist` |
| 工作台安装目标 | `frontend/public/genoffice`；脚本复制 dist，再注入 bridge 与 embedded CSS |
| 实际 HTML 引用 | [index.html:11–13][renderer-index] 引用 `index-C6VczQUm.js`、`index-BPaMYPw8.css`、`bridge-shim.js` |
| 宿主接线补丁 | [上游 App.tsx:5019–5065][renderer-app] 接收版本化 postMessage，调用 `protocol-office.ts`，监听编辑更新同步引文 |

已计算的 SHA-256：

```text
工作台 renderer JS
091b95d8ad340cd3d251c7088522cd76c84f7651ff7402009c9aff95988456f6

上游 dist 同名 renderer JS
091b95d8ad340cd3d251c7088522cd76c84f7651ff7402009c9aff95988456f6

bridge-shim.js
572f3875c76bf72585cd9f0fb6bbafbba78349edb98bcd23cd6b097fb15054e8

build_genoffice_renderer.sh
e2d9296bf856db2b4b3168205f686716764538e87ba371a53633ebcd0bc33af8

上游 protocol-office.ts
eea5b061e731fb8ffc317d626de2bbf430c7af8eb937769ccd60cd6ea89d481d
```

**可确认工作台 JS 与当前上游 dist JS 字节一致；不能确认它可由上游 HEAD 单独重建。** 构建依赖未提交及未跟踪补丁，脚本没有固定 commit 或校验补丁清单。

本轮未访问运行服务，故以下仍为 **UNVERIFIED**：服务实际加载的 bundle、进程启动时源码版本、前后端启用 flags、实际数据库与制品根。源码可确认 Office 根为 `adapter_config['path'] + '.office-artifacts'`，full-draft 根为 `RUNTIME_DIR/medical_writing_full_drafts`；不能把这两个表达式当作已核验的运行路径。[composition:275–278][office-root]；[main:2567–2570][full-service]

**四、用户可见能力、历史证据及新增问题**

应保留的当前能力：

- **桌面密度：** 已有左右 pane、左侧内部滚动、只读起草依据折叠及专注编辑。CSS 明确桌面两列，不能继续将旧“大单列简化预览”描述为当前原样状态。[Desk:8–15][desk]；[CSS:202–224][desk-css]
- **编辑所有权：** 旧语义章节预览已不传 edit；Office 会话参数冻结，新候选不自动替换已存 Word；历史下载不写 head。
- **选区：** 有真实 renderer 命令、映射锚点、原文比较、条件替换与撤销；范围只限同一 textblock，不等于整表／整摘要结构化改写。[protocol-office:49–90][renderer-patch]
- **引文：** 插入 `ADDIN CMS_CITATION` 字段，按首次出现编号，并维护受管文献表；上游保存来源模型已补作者数组、卷期页码 DOI。[protocol-office:100–135、150–228][renderer-patch]；[sources.ts:95–151][renderer-sources]
- **核对：** 当前 Office 核对已经读取 DOCX 字节，不应沿用旧记录“完全未接线”的结论；其能力仍是有限定位。

历史证据只能按原范围继承：

| 历史记录 | 可保留的证据 | 不可外推 |
|---|---|---|
| [TAKEOVER_REVIEW:49–53、75–88][history] | 记录了隔离 renderer/API 中文插入、保存、下载、重开；后来实际 React 宿主历史版本下载；多桌面宽度观察 | 不是双入口完整模型旅程通过；不是所有格式／选区／引文通过 |
| [verification.json:2–22][office-history-json] | 记录前后 hash、marker 保留、1 张表、页眉页脚字节未变 | “页眉未变”不等于“页眉编辑保存通过” |
| [native_word_verification.json:2–10][native-history] | 记录原生 Word 打开及目录链接观察；保存前后 hash 相同 | 未证明 Word 改写后持久化；明确未验全稿及真实临床内容 |
| [TAKEOVER_REVIEW:82–86][history] | 后续记录特定合成文档页眉对齐修正和实际观察 | 不能把较早页眉问题继续机械列为未修；也不能据此宣布全稿接受 |

历史记忆曾指出 `b:Sources` 自闭合根及作者身份问题。本轮重新读取当前上游源码，已见根标签正规化、作者数组和元数据扩展，**不将旧 P0 原样重新登记**；当前产物 XML 与原生 Word 往返仍未运行核验。

新增问题限定为以下 **6 条**，与专家已有 F01–F09 去重：

| 编号 | 级别 | 具体因果及用户影响 | 最小建议 |
|---|---|---|---|
| W01 | P1 | 摘要确认结果落在 journey；App 只切项目，flag 开启后新工作台从自己的 brief/run 状态开始，未承接确认结果。用户完成提取后仍可能重新输入／整理，既有确认不能证明进入 Word 链。[app-switch] [protocol-intake] | 补入口交接适配，复用来源和确认记录 |
| W02 | P1 | full-draft adopt 写旧章节库；GenOffice 读 manuscript/Office。采纳成功及旧 DOCX 导出都不能证明当前 Word 获得该正文。[full-adopt] [documents] | 一个候选接收入口、一个当前 Word 所有者；不做双库持续同步 |
| W03 | P2 | Office projection 对含数字事实允许“数字出现在任意正文块”即定位；零项检查且无诊断也返回 `consistent_within_checked_scope`。UI 无差异时仍显示未发现确定数值缺失，可能把未覆盖显示成核对成果。[projection:40–76][projection]；[Frame:412–420][office-ui] | 零覆盖用 `not_checked`；数字匹配只作线索，关联事实类型／上下文并展示覆盖，不阻断保存 |
| W04 | P2 | 引文顺序或条目文本变化时，renderer 删除所有受管文献表块，再于文末以固定节点重建。用户移动文献表或修改格式后，后续引文操作可丢失位置／样式。[protocol-office:198–223][renderer-patch] | 原位更新受管条目，保留容器位置及格式；无需新增文献编辑库 |
| W05 | P2 | 选区基线与撤销仅存字符串，应用／撤销均 `insertText()`。文字未变但富文本、字段或标记改变时，比较仍可能通过；撤销也无法恢复原完整结构。[protocol-office:14–17、55–87][renderer-patch] | 保留原范围 slice／结构签名；或明确限制纯文本选区，对不支持结构拒绝，而非承诺无损 |
| W06 | P2 | 关键 renderer 桥接存在于上游未跟踪文件，工作台仅保存 bundle；仅记录两仓 HEAD 无法重建当前编辑能力。[renderer-build] [renderer-app] | 固定补丁集／源码快照、commit、构建及资源 hash，作为一次交付记录，不另建发布框架 |

专家 F06 仍有直接源码依据：bridge 在 HTTP 成功后 JSON 失败降为 `{}`，清 operation 并返回 `ok:true`。[bridge:120–127][bridge]。该项不重复计入新增问题，WP5 必须保留。

**五、WP0–WP6 的边界建议**

| 工作包 | 建议保留及收窄的边界 |
|---|---|
| WP0 | 先明确主路径及两套研究／文档身份映射，记录入口交接、候选接收断点；冻结工作台 SHA、renderer dirty 补丁及 bundle hash。运行 DB、flags、部署版本由 owner 在允许的运行核验中补齐，不用源码默认值代替。 |
| WP1 | 在现有 manuscript 接收合同表达“可靠正文＋局部缺口＋候选”。Office 当前稿仍是唯一用户正文。不要另建工作稿数据库，也不要为接收工作稿强迫全部章节 complete。 |
| WP2 | 复用现有事务、幂等及回执。决定确认、候选重组、工作稿接收分别恢复；不靠旧章节逐章写入再同步 Word。未变候选和人工 Word 均须保留，但二者不能混称同一新研究基线全文。 |
| WP3 | 科学核对由 owner 负责；本审阅仅要求其结果绑定当前 study 与候选／Office snapshot。保留有限定位，不能让它替代语义判断，也不应让核对失败阻止输入保存。 |
| WP4 | 沿现有 descriptor／制品补来源 manifest。特别验证摘要入口及已上传项目文件进入实际生成输入；保留现有引用身份校验，不新增逐句审批平台。 |
| WP5 | 集中修保存回执合同、renderer 补丁可重建性及明确的选区／引文保真问题。保留最新快照打开下载、显式候选选择、冻结 iframe、导航保护、历史及失败备份。 |
| WP6 | 先集中完成受影响合同及故障场景检查，再冻结版本做双入口真实用户批次。每条链记录输入事件、研究版本、候选身份、Office 操作及下载 hash。独立宿主证据可继承其有限范围；完整 App、实际模型、原生 Word、医学接受分别记录。 |

无需每改一处运行整批测试，也无需每包固定再会商。按合同变化集中验证，只有新增实质解释分歧或重要主观接受判断再安排独立复核。既有检索、OCR、翻译、候选、历史 Word 和已验证局部能力应保留。

**本审阅完成状态：源码接线与本地构建指向已核对；双入口统一到当前 Word 尚有明确断点；运行集成、当前部署、原生 Word 往返及医学接受均未由本轮核验。** 本报告由 owner 保存，本 reviewer 未创建或修改任何文件。

[app-entry]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/frontend/src/App.jsx:1474
[app-create]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/frontend/src/App.jsx:1297
[intake]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/frontend/src/features/medical-writing/MedicalWritingSynopsisProjectIntake.jsx:250
[project-create]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/services/api/app/main.py:3910
[synopsis-confirm]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/services/api/app/main.py:7464
[setup]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/frontend/src/features/medical-writing/MedicalWritingAuthoringJourneySetup.jsx:1121
[package-panel]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/frontend/src/features/medical-writing/AuthoringCandidatePackagePanel.jsx:911
[journey]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/services/api/app/medical_writing_authoring_journey.py:5989
[project-navigation]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/frontend/src/App.jsx:15539
[app-switch]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/frontend/src/App.jsx:16156
[setup-create]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/frontend/src/features/medical-writing/MedicalWritingAuthoringJourneySetup.jsx:2326
[greenfield]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/services/api/app/main.py:9109
[source-intake]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/frontend/src/features/medical-writing/protocol-workbench/ProtocolSourceIntake.jsx:456
[research-intake]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/services/api/app/protocol_workflow/api/research_intake.py:44
[design]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/services/api/app/protocol_workflow/api/design.py:144
[research-context]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/services/api/app/protocol_workflow/application/research_context.py:9
[full-ui]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/frontend/src/App.jsx:10445
[full-service]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/services/api/app/main.py:2567
[manuscript-workspace]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/frontend/src/features/medical-writing/protocol-workbench/ManuscriptWorkspace.jsx:265
[composition]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/services/api/app/protocol_workflow/api/composition.py:410
[full-adopt]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/services/api/app/medical_writing_full_draft.py:1300
[manuscript-save]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/services/api/app/protocol_workflow/api/manuscript_drafts.py:443
[documents]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/services/api/app/protocol_workflow/application/manuscript_documents.py:17
[manuscript-view]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/frontend/src/features/medical-writing/protocol-workbench/ManuscriptWorkspace.jsx:548
[office-open]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/frontend/src/features/medical-writing/protocol-workbench/office/GenOfficeFrame.jsx:218
[bridge]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/frontend/public/genoffice/bridge-shim.js:85
[office-store]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/services/api/app/protocol_workflow/application/manuscript_documents.py:738
[office-api]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/services/api/app/protocol_workflow/api/manuscript_drafts.py:672
[office-reconcile]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/services/api/app/protocol_workflow/application/manuscript_documents.py:878
[legacy-export]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/services/api/app/main.py:9819
[office-ui]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/frontend/src/features/medical-writing/protocol-workbench/office/GenOfficeFrame.jsx:381
[manuscript-export]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/services/api/app/protocol_workflow/api/manuscript_drafts.py:195
[protocol-intake]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/frontend/src/features/medical-writing/protocol-workbench/ProtocolIntakeWorkspace.jsx:27
[study-context]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/frontend/src/features/medical-writing/protocol-workbench/StudyContextWorkspace.jsx:64
[working-repo]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/services/api/app/medical_writing_repository.py:893
[working-store]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/services/api/app/sqlite_runtime_store.py:9130
[renderer-build]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/scripts/qc/protocol_v3/build_genoffice_renderer.sh:7
[renderer-index]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/frontend/public/genoffice/index.html:11
[renderer-app]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/genoffice-upstream/apps/docs/src/renderer/App.tsx:5019
[office-root]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/services/api/app/protocol_workflow/api/composition.py:275
[desk]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/frontend/src/features/medical-writing/protocol-workbench/ProtocolWritingDesk.jsx:8
[desk-css]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/frontend/src/features/medical-writing/protocol-workbench/ProtocolIntakeWorkspace.css:202
[renderer-patch]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/genoffice-upstream/apps/docs/src/renderer/protocol-office.ts:49
[renderer-sources]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/genoffice-upstream/packages/docx-engine/src/sources.ts:95
[history]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/runs/requirements_v2_20260919/t17_round11/TAKEOVER_REVIEW.md:49
[office-history-json]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/runs/requirements_v2_20260919/t17_round11/office_browser_isolated/verification.json:2
[native-history]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/runs/requirements_v2_20260919/t17_round11/office_browser_isolated/native_word_verification.json:2
[projection]: /Users/smkzw/Documents/康哲项目资料/AI/医学经理工作台/implementation/protocol-v3-workbench-mw_protocol_v3_phase0_20260809_111313/services/api/app/protocol_workflow/application/office_projection.py:40

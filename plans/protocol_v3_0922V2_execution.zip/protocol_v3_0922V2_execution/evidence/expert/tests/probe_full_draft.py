"""Run copied-method regression probes. This is NOT a full-repository test.
Mocked boundary: repo, artifact loading/integrity, decision registry, job queue,
request models, process-marker validators. Each case reports actual behavior
against a narrowly stated desired contract. Failures document review findings.
"""
import sys, json, hashlib, copy
from pathlib import Path
from types import SimpleNamespace as NS
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'sources'))
from full_draft_methods import MedicalWritingFullDraftService as S, StaleRuntimeStateError

OUT = Path(__file__).resolve().parents[1] / 'evidence' / 'full_draft_probe_results.json'
results = []
def record(key, expected, actual, passed, scope='copied_method_mocked_dependencies'):
    results.append(dict(id=key, expected=expected, actual=actual, meets_expected_contract=bool(passed), scope=scope))
def sha(text): return hashlib.sha256(text.encode()).hexdigest()

class Repo:
    def __init__(self):
        self.study_rev = 1
        self.study_sha = 'a'*64
        self.doc = NS(document_id='doc:test', version='草案')
        self.working = {k: NS(revision=0, content_blocks=[{'block_id':'b:'+k, 'block_type':'paragraph', 'text':''}]) for k in ['s1','s2']}
        self.saved = []
    def protocol(self, project): return self.doc
    def working_copy(self, project, section): return self.working[section]
    def save_working_copy(self, project, section, request):
        current = self.working[section]
        if current.revision != request.expected_revision: raise StaleRuntimeStateError('mock CAS conflict')
        current.revision += 1
        current.content_blocks = copy.deepcopy(request.content_blocks)
        self.saved.append((section, request.idempotency_key))
        return current

PROSE = '本节说明研究资料的整理范围。' * 10

def make_fixture():
    repo = Repo()
    service = S()
    artifact = dict(schema_version='protocol_full_draft_artifact_v9',document_id='doc:test',document_version='草案',
        study_definition={'id':'study:test','revision':1,'sha256':'a'*64},
        target_sections=[{'section_id':k,'body_block_id':'b:'+k,'expected_revision':0,'body_sha256':sha('')} for k in ['s1','s2']],
        sections=[{'section_id':k,'heading':'资料整理','proposal_text':PROSE+k,'content_status':'complete','review_level':'standard'} for k in ['s1','s2']],
        coverage={})
    service._service = lambda project: NS(repo=repo)
    service.read_artifact = lambda project,job: copy.deepcopy(artifact)
    service._binding = lambda r,p,d: {'id':'study:test','revision':r.study_rev,'sha256':r.study_sha}
    service._artifact_evidence_is_resolvable = lambda a: True  # boundary not under test
    return service,repo,artifact,NS(job_id='job:test')

# Test 1: rule incorrectly asserts a conflict solely from a composite phrase.
r=S._review_policy('统计分析','所有随机受试者；停药这一伴发事件采用复合策略。',0)
record('0922V2-P01','不得凭复合策略一个词断言同时存在治疗策略',r,
       not any('同时出现治疗策略' in x for x in r['review_reasons']))

# Test 2: identical proposed same-event conflict changes status with heading.
conflict='同一停药事件采用治疗策略并使用观察结局；该停药事件又采用复合策略强制判为无应答。'
a=S._review_policy('统计分析',conflict,0)
b=S._review_policy('主要估计目标',conflict,0)
record('0922V2-P02','同一科学问题不得因标题变化而逃离同一核对问题组',
       {'统计分析':a['review_level'],'主要估计目标':b['review_level']}, a['review_level']==b['review_level'])

# Control: generic narrative is not arbitrarily a required decision.
r=S._review_policy('资料整理','研究资料按已确认的来源版本管理。',0)
record('0922V2-P03','普通说明不被强制升级',r['review_level'],r['review_level']=='standard')

# Test 4: one noncritical gap rejects the entire working-draft adoption.
s,repo,art,job=make_fixture(); art['sections'][1].update(content_status='source_gap',proposal_text='',missing_source_classes=['最终联系人'])
try: value=s.adopt('p:test',job); error=None
except Exception as exc: error=str(exc)
record('0922V2-P04','工作稿可纳入已支持正文并保留非关键缺口，不冒充最终放行',
       {'error':error,'saved_sections':repo.saved}, error is None)

# Test 5: later section stale after section 1 has already been committed.
s,repo,art,job=make_fixture(); repo.working['s2'].revision=1
try: value=s.adopt('p:test',job); error=None
except Exception as exc: error=str(exc)
record('0922V2-P05','整包失败时应不留下未报告的部分写入；或返回可恢复的明确部分结果',
       {'error':error,'saved_sections':repo.saved,'s1_revision':repo.working['s1'].revision},
       error is None or len(repo.saved)==0)

# Control: two clean sections do commit successfully.
s,repo,art,job=make_fixture(); value=s.adopt('p:test',job)
record('0922V2-P06','两节正常采纳控制',value,value['adopted_count']==2)

# Test 7: descriptor hashes multiple paragraph texts, adopter checks one.
s,repo,art,job=make_fixture()
art['sections']=art['sections'][:1]; art['target_sections']=art['target_sections'][:1]
repo.working['s1'].content_blocks=[{'block_id':'b:s1','block_type':'paragraph','text':'已有标题说明'},
                                {'block_id':'b2:s1','block_type':'paragraph','text':'另一段简短说明'}]
# This is the join expression in _body_text of the inspected source.
joined='\n'.join(b['text'].strip() for b in repo.working['s1'].content_blocks if b['text'].strip()).strip()
art['target_sections'][0]['body_sha256']=sha(joined)
try: value=s.adopt('p:test',job); error=None
except Exception as exc: error=str(exc)
record('0922V2-P07','未发生编辑的多段初始正文不应被错误判为版本冲突',
       {'joined_hash':sha(joined),'first_hash':sha('已有标题说明'),'error':error},error is None)

# Decision fixtures: test actual ordering, not real decision writer semantics.
def decision_fixture(fail_enqueue=False):
    s,repo,art,job=make_fixture()
    fact='picos.exploratory_objectives'
    item={'fact_path':fact,'question':'是否设置探索性目的','recommended_option_id':'none',
          'options':[{'option_id':'none','summary':'不设置探索性目的'}]}
    art['sections'][0].update(content_status='decision_required',proposal_text='',decision_items=[item])
    art['decision_path_owners']={fact:'s1'}
    s.decision_index=lambda a: {'decision:test': {'section_id':'s1','content_status':'decision_required','item':item}}
    s._available_decision_paths=lambda service,p: {fact}
    s._decision_fact_value=lambda path,prose: prose
    calls=[]; queues=[]
    def writer(project,**kw):
        calls.append(kw);repo.study_rev=2;repo.study_sha='b'*64
        return NS(study_definition=NS(revision=2),revision=2)
    def queue(project,store,**kw):
        queues.append(kw)
        if fail_enqueue: raise RuntimeError('injected enqueue failure AFTER fact persistence')
        return 'job:scoped',False
    s.submit_durable=queue
    args=dict(decisions=[{'decision_id':'decision:test','option_id':'none'}],idempotency_key='op:test',study_definition_writer=writer)
    return s,repo,art,job,args,calls,queues

# Test 8: fact confirmation committed, queue failed, retry fails stale before recovery.
s,repo,art,job,args,calls,queues=decision_fixture(True)
errors=[]
for _ in range(2):
    try: s.resolve_decision('p:test',None,job,**args)
    except Exception as exc: errors.append(str(exc))
record('0922V2-P08','事实确认已提交后同一操作重试应恢复/补派，而非旧基线提前拦截',
       {'errors':errors,'writer_calls':len(calls),'enqueue_calls':len(queues),'study_revision':repo.study_rev},
       len(queues)>1)

# Test 9: two coupled facts cannot be submitted in one bundle.
s,repo,art,job,args,calls,queues=decision_fixture()
args['decisions'].append({'decision_id':'decision:second','option_id':'none'})
try: s.resolve_decision('p:test',None,job,**args); error=None
except Exception as exc: error=str(exc)
record('0922V2-P09','相互依赖的目的/终点应可在单一原子选择内提交',error,error is None)

# Test 10: owner-only regeneration leaves the old full artifact stale.
s,repo,art,job,args,calls,queues=decision_fixture()
res=s.resolve_decision('p:test',None,job,**args)
try: s.adopt('p:test',job); error=None
except Exception as exc: error=str(exc)
record('0922V2-P10','局部补写后应有可组合的全稿基线，不使未变章节候选只能废弃',
       {'regeneration_scope':res['regeneration']['section_ids'],'old_full_adoption_error':error,
        'note':'本探针仅证明旧整稿失效且新任务仅一节；跨层是否补充重组需浏览器/集成验证。'},
       error is None,scope='copied_method; recomposition gap requires integration verification')

# Test 11: same artifact metadata, fresh/reused locators omit different fields.
ids=['mwsec_greenfield_'+'x'*32+'_'+str(i) for i in range(85)]
coverage={'target_count':85,'generated_count':85,'required_review_count':1,'required_review_section_ids':ids[:1],
          'decision_required_count':1,'decision_required_section_ids':ids[1:2],
          'source_gap_count':40,'source_gap_section_ids':ids[2:42], 'section_ids':ids,'adoption_ready':False}
base={'schema_version':'protocol_full_draft_artifact_v9', 'artifact_relpath':'p/'+'j'*32+'/full-draft.json',
      'artifact_sha256':'a'*64,'precondition_digest':'b'*64}
# These comprehensions reproduce the exact two inspected branch expressions.
reused={k:v for k,v in coverage.items() if k!='section_ids'}
fresh={k:v for k,v in coverage.items() if k not in {'section_ids','required_review_section_ids','decision_required_section_ids','source_gap_section_ids'}}
canon=lambda v:json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'))
lengths={'fresh_locator_chars':len(canon({**base,'coverage':fresh})),
         'reused_locator_chars':len(canon({**base,'coverage':reused})),
         'commented_capacity':2000,
         'note':'合成等长度ID，不是完整冻结工件；未运行真实DurableJobRecord校验。'}
record('0922V2-P11','复用路径与首次路径的定位器摘要字段应一致且有同一容量上限',
       lengths,fresh==reused,scope='exact_branch_expression_probe; synthetic metadata')

summary={'round':'0922V2','commit':'acf6d8341563d56946f934dfdac65c76997e36e3',
         'test_scope':'isolated copied-method probes; mocked dependencies; NOT real application/DB/browser/Word',
         'count':len(results),'meets_expected':sum(r['meets_expected_contract'] for r in results),
         'does_not_meet_expected':sum(not r['meets_expected_contract'] for r in results),'results':results}
OUT.write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))

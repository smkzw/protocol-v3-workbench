/** 0922V2: real hash-verified bridge in Node VM; fetch/window are mocks.
 * No renderer, server, browser, DOCX parser or Word is executed.
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { webcrypto, createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const source=fs.readFileSync(path.join(root,'sources/bridge-shim.js'),'utf8');
const verification=JSON.parse(fs.readFileSync(path.join(root,'evidence/bridge_source_verification.json')));
if(!verification.matches)throw new Error('source Git blob verification failed');
const results=[];
const bytes=new TextEncoder().encode('synthetic byte array; not claimed valid DOCX').buffer;
const hash=data=>createHash('sha256').update(Buffer.from(data)).digest('hex');
const response=(body,{status=201,brokenJson=false}={})=>({ok:status>=200&&status<300,status,
  headers:{get:()=>null},json:async()=>{if(brokenJson)throw new Error('invalid JSON');return body;}});
function fixture(responder,{withOpen=false}={}){
  const posts=[],events=[];let uuid=0;
  const query=new URLSearchParams({saveUrl:'/snapshots',rev:'5',sha:'a'.repeat(64),openedStudySha:'b'.repeat(64),baseArtifactRevision:'4'});
  if(withOpen)query.set('docUrl','/snapshot/docx');
  const win={location:{search:'?'+query.toString(),origin:'https://workbench.test'},parent:{postMessage:(msg,origin)=>events.push({msg,origin})}};
  const context={window:win,URLSearchParams,Uint8Array,ArrayBuffer,Array,Number,String,Object,Promise,Proxy,
    crypto:{subtle:webcrypto.subtle,randomUUID:()=>`uuid-${++uuid}`},
    btoa:s=>Buffer.from(s,'binary').toString('base64'),
    fetch:async(url,options={})=>{
      if(options.method!=='POST')return {ok:true,status:200,headers:{get:()=> '4'},arrayBuffer:async()=>bytes.slice(0)};
      const body=JSON.parse(options.body);posts.push(body);return responder(body,posts.length);
    }};
  vm.runInNewContext(source,context,{filename:'hash-verified-bridge-shim.js'});
  return {api:win.desktop,posts,events};
}
function add(id,expected,actual,meets){results.push({id,expected,actual,meets_expected_contract:!!meets});}
const valid=body=>({operation_id:body.operation_id,artifact_revision:5,persisted:true,
  content_sha256:hash(Buffer.from(body.content_base64,'base64')),
  snapshot_id:'office-snapshot:'+hash(Buffer.from(body.content_base64,'base64'))});

// success controls and regression probes
{
 const f=fixture(body=>response(valid(body)));const r=await f.api.saveDocx('p',bytes);
 add('0922V2-B01','合法且一致的持久化回执允许成功',r,r.ok===true);
}
{
 const f=fixture(()=>response({}, {brokenJson:true}));const r=await f.api.saveDocx('p',bytes);
 add('0922V2-B02','HTTP成功但JSON损坏必须保持结果未知和原操作身份',
     {result:r,retainedOperationId:f.api.saveDocx.operationId},r.ok===false && !!f.api.saveDocx.operationId);
}
{
 const f=fixture(()=>response({persisted:false}));const r=await f.api.saveDocx('p',bytes);
 add('0922V2-B03','persisted=false不能被当作保存成功',r,r.ok===false);
}
{
 const f=fixture(()=>response({operation_id:'other-operation',artifact_revision:999,persisted:true,content_sha256:'0'.repeat(64)}));
 const r=await f.api.saveDocx('p',bytes);
 add('0922V2-B04','回执操作身份与内容哈希不一致必须拒绝确认',r,r.ok===false);
}
{
 const f=fixture((body,n)=>{if(n===1)throw new Error('simulated lost network acknowledgement');return response(valid(body));});
 const first=await f.api.saveDocx('p',bytes);const second=await f.api.saveDocx('p',bytes);
 add('0922V2-B05','网络失败重试应保持原operation_id（旧问题修复控制）',
     {first,second,operationIds:f.posts.map(p=>p.operation_id)},
     first.ok===false&&second.ok===true&&f.posts[0].operation_id===f.posts[1].operation_id);
}
{
 const f=fixture(()=>response({detail:{code:'manuscript_office_base_conflict',latest_snapshot:{artifact_revision:9}}},{status:409}));
 const r=await f.api.saveDocx('p',bytes);
 add('0922V2-B06','冲突不伪报成功且保留原待核实操作',
     {result:r,retainedOperationId:f.api.saveDocx.operationId},r.ok===false&&r.conflict===true&&!!f.api.saveDocx.operationId);
}
{
 const f=fixture(body=>response(valid(body)));const r=await f.api.exportPdf();const p=await f.api.setDocPassword('secret');
 add('0922V2-B07','未实现导出和密码必须显式unsupported（旧问题修复控制）',
     {exportPdf:r,password:p},r.ok===false&&r.unsupported===true&&p.ok===false&&p.unsupported===true);
}
{
 const f=fixture(body=>response(valid(body)),{withOpen:true});const r=await f.api.consumePendingOpenDocx();
 add('0922V2-B08','启动可获取目标文档而非永远空值（旧问题修复控制）',
     {path:r?.path,byteLength:r?.data?.byteLength},r?.path==='/snapshot/docx'&&r.data.byteLength>0);
}
const summary={round:'0922V2',commit:'acf6d8341563d56946f934dfdac65c76997e36e3',source_git_blob_verified:true,
 scope:'full original bridge source in Node VM; mocked window/fetch; NOT browser/renderer/Word',
 count:results.length,meets_expected:results.filter(x=>x.meets_expected_contract).length,
 does_not_meet_expected:results.filter(x=>!x.meets_expected_contract).length,results};
fs.writeFileSync(path.join(root,'evidence/bridge_probe_results.json'),JSON.stringify(summary,null,2)+'\n');
console.log(JSON.stringify(summary,null,2));

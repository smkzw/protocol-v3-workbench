# 0922V2 — Protocol v3 复审交付包

主报告：[0922V2_REVIEW](docs/0922V2_REVIEW.md)

交给实施 Agent：[0922V2_AGENT_NEXT](docs/0922V2_AGENT_NEXT.md)

机器可读发现：`findings.json`；来源与覆盖：`source_manifest.json`；运行状态：`verification.json`。

`tests/`是缺陷复现/行为观察程序，不是修复补丁，也不是整个产品测试套件。运行结果会记录不符合预期的行为，不能把脚本进程成功退出当作缺陷已修复。

```bash
python tests/probe_full_draft.py
node tests/probe_bridge.mjs
```

桥接整文件在`source_verification`中通过Git blob核对；其他文件是方法节选及模拟边界。没有包含字体、整个上游库、密钥或患者资料。没有修改或推送用户仓库。

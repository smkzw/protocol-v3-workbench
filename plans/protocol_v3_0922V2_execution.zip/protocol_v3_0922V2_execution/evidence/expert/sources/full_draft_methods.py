"""0922V2 audit method excerpts, NOT an installed copy of the repository.

Original: services/api/app/medical_writing_full_draft.py
Commit: acf6d8341563d56946f934dfdac65c76997e36e3
Full original Git blob: d816f1e33dd889f8e4675c76a10ddacba5e9e3cd
Methods copied from connector reads. Surrounding imports/dependencies supplied
by tests are synthetic. No actual model, application DB, browser, or Word runs.
"""
import hashlib
import re
from typing import Any, Mapping, Iterable, Callable, Optional

FULL_DRAFT_ARTIFACT_SCHEMA = 'protocol_full_draft_artifact_v9'
LEGACY_FULL_DRAFT_ARTIFACT_SCHEMAS = {f'protocol_full_draft_artifact_v{i}' for i in range(3, 9)}
FULL_DRAFT_REVIEW_POLICY_VERSION = 'protocol_full_draft_review_v0_2'
FULL_DRAFT_MINIMUM_BODY_CHARS = 80
SUPPORTED_ADOPT_PATHS = {'picos.exploratory_objectives', 'picos.exploratory_endpoints'}
_DECISION_STRUCTURED_DESIGN_PATHS = frozenset({'design.src_dmc', 'design.phase1_parts', 'design.arms_or_cohorts'})
_PLACEHOLDER_RE = re.compile(
    r"(?:^|[\s，。；：])(?:待补充|待确认|待定|TBD|TODO|不适用|无适用内容|由方案规定|见方案规定)(?:$|[\s，。；：])",
    re.IGNORECASE,
)
_REQUIRED_REVIEW_HEADING_RE = re.compile(
    r"^(?:方案概要|研究目的和终点|主要目的和主要终点|主要终点.*|研究设计|总体设计|"
    r"确证性设计与假设依据|随机化|盲法与揭盲|研究人群|研究人群选择及依据|"
    r"入选标准|排除标准|统计分析|(?:主要)?估计目标.*|样本量.*|非劣效.*|"
    r"期中分析.*|多重性.*|剂量选择.*|对照选择.*|研究药物相关风险|"
    r"妊娠事件(?:的报告与随访)?|避孕的规定与方法|安全信息报告途径)$",
    re.IGNORECASE,
)
_REQUIRED_REVIEW_CONTENT_RE = re.compile(
    r"主要终点|估计目标|伴发事件|样本量|计划入组|非劣效界值|期中分析|alpha|α|"
    r"剂量选择|对照选择|核心人群",
    re.IGNORECASE,
)
_CORPUS_CONDUCT_RE = re.compile(
    r"避孕|妊娠.{0,24}(?:报告|随访|结局)|不良事件.{0,20}(?:是指|定义|记录|报告)|"
    r"严重不良事件.{0,30}(?:记录|报告)|剂量(?:调整|暂停|减量)|给药中断|永久停药|"
    r"合并用药|禁用药|限制用药|洗脱|救援治疗|IWRS|交互式网络应答|"
    r"侵入性操作|全分析集|符合方案集|安全性分析集",
    re.IGNORECASE,
)
_DESIGN_RESTATEMENT_SIGNALS = (
    re.compile(r"计划入组\s*\d+\s*例"),
    re.compile(r"\d+(?:\.\d+)?\s*mg", re.IGNORECASE),
    re.compile(r"主要终点"),
    re.compile(r"随机"),
    re.compile(r"双盲"),
)
_DESIGN_RESTATEMENT_ALLOWED_HEADING_RE = re.compile(
    r"方案概要|研究设计|研究目的和终点|主要目的和主要终点|样本量", re.IGNORECASE,
)

# These two validators are synthetic, deliberately neutral for the tested
# clean, substantive prose. Their implementation is NOT being audited here.
INTERNAL_TRANSPORT_VOCABULARY_RE = re.compile(r'(?!)')
DRAFTING_PROCESS_VOCABULARY_RE = re.compile(r'(?!)')
def iter_unresolved_draft_markers(_):
    return iter(())

class RuntimeStoreError(Exception):
    pass
class StaleRuntimeStateError(RuntimeStoreError):
    pass
class DurableJobStore:
    pass
class MedicalWritingWorkingCopySaveRequest:
    def __init__(self, **values):
        self.__dict__.update(values)

def _text(value):
    return str(value or '').strip()

class MedicalWritingFullDraftService:
    @staticmethod
    def _review_policy(heading: str, proposal: str, corpus_count: int) -> dict[str, Any]:
        required_reasons: list[str] = []
        advisory_reasons: list[str] = []
        heading_signals = sorted(
            {
                match.group(0)
                for match in _REQUIRED_REVIEW_HEADING_RE.finditer(heading)
            }
        )
        embedded_signals = sorted(
            {match.group(0) for match in _REQUIRED_REVIEW_CONTENT_RE.finditer(proposal)}
        )
        if heading_signals:
            advisory_reasons.append(
                f"本节复述高影响研究设计（{'、'.join(heading_signals[:6])}）；请在合并设计摘要中统一核对。"
            )
        if embedded_signals:
            advisory_reasons.append(
                f"本节提及高影响设计信息（{'、'.join(embedded_signals[:6])}）；系统未把重复提及升级为强制确认。"
            )
        if corpus_count and _CORPUS_CONDUCT_RE.search(proposal):
            advisory_reasons.append(
                "本节引用公司语料形成共性表述；定稿时请用本项目权威文件复核适用性。"
            )
        if (
            heading == "统计分析"
            and "复合策略" in proposal
        ):
            required_reasons.append(
                "估计目标同时出现治疗策略人群与复合策略；请由统计负责人统一伴发事件策略后再采纳。"
            )
        restatement_count = sum(
            bool(pattern.search(proposal)) for pattern in _DESIGN_RESTATEMENT_SIGNALS
        )
        if (
            restatement_count >= 3
            and not _DESIGN_RESTATEMENT_ALLOWED_HEADING_RE.search(heading)
        ):
            advisory_reasons.append(
                "本节重复了多项总体设计事实；建议压缩为与本节直接相关的信息。"
            )
        return {
            "review_level": "required" if required_reasons else "standard",
            "review_reasons": required_reasons,
            "review_advisories": advisory_reasons,
        }

    @classmethod
    def _apply_review_policy(cls, artifact: dict[str, Any]) -> dict[str, Any]:
        required_ids: list[str] = []
        decision_ids: list[str] = []
        source_gap_ids: list[str] = []
        for section in artifact.get("sections") or []:
            content_status = _text(section.get("content_status")) or "complete"
            if content_status == "decision_required":
                section.update({
                    "review_level": "blocked",
                    "review_reasons": ["本节包含尚未确认的科学决定；请先在研究设计中选择推荐项或备选项。"],
                    "review_advisories": [],
                })
                decision_ids.append(_text(section.get("section_id")))
                continue
            if content_status == "source_gap":
                section.update({
                    "review_level": "blocked",
                    "review_reasons": ["本节缺少可引用来源；补充所列资料后再生成正文。"],
                    "review_advisories": [],
                })
                source_gap_ids.append(_text(section.get("section_id")))
                continue
            evidence_summary = section.get("evidence_summary") or {}
            section.update(
                cls._review_policy(
                    _text(section.get("heading")),
                    _text(section.get("proposal_text")),
                    int(evidence_summary.get("corpus_spans") or 0),
                )
            )
            if section.get("review_level") == "required":
                required_ids.append(_text(section.get("section_id")))
        coverage = artifact.setdefault("coverage", {})
        coverage["required_review_count"] = len(required_ids)
        coverage["required_review_section_ids"] = required_ids
        coverage["decision_required_count"] = len(decision_ids)
        coverage["decision_required_section_ids"] = decision_ids
        coverage["source_gap_count"] = len(source_gap_ids)
        coverage["source_gap_section_ids"] = source_gap_ids
        is_legacy = artifact.get("schema_version") in LEGACY_FULL_DRAFT_ARTIFACT_SCHEMAS
        evidence_chain_resolvable = (
            not is_legacy and cls._artifact_evidence_is_resolvable(artifact)
        )
        coverage["legacy_read_only"] = is_legacy
        coverage["evidence_chain_resolvable"] = evidence_chain_resolvable
        coverage["adoption_ready"] = (
            evidence_chain_resolvable and not decision_ids and not source_gap_ids
        )
        artifact["review_policy_version"] = FULL_DRAFT_REVIEW_POLICY_VERSION
        return artifact

    def adopt(
        self,
        project_id: str,
        job: Any,
        *,
        actor: str = "medical_manager",
        confirmed_section_ids: Iterable[str] = (),
    ) -> dict[str, Any]:
        artifact = self.read_artifact(project_id, job)
        if artifact.get("schema_version") != FULL_DRAFT_ARTIFACT_SCHEMA:
            raise RuntimeStoreError("旧版全文初稿候选仅供查阅；请按当前研究事实重新生成后再采纳")
        if not self._artifact_evidence_is_resolvable(artifact):
            raise RuntimeStoreError("全文初稿章节证据链不完整，未采纳")
        service = self._service(project_id)
        repo = service.repo
        document = repo.protocol(project_id)
        if str(document.document_id) != str(artifact.get("document_id")):
            raise RuntimeStoreError("全文初稿所属文档已变化，未采纳")
        if str(document.version) != str(artifact.get("document_version")):
            raise RuntimeStoreError("全文初稿所属文档版本已变化，未采纳")
        if self._binding(repo, project_id, document) != artifact.get("study_definition"):
            raise RuntimeStoreError("研究设计绑定已变化，未采纳全文初稿")
        candidates = {str(item.get("section_id")): item for item in artifact.get("sections") or []}
        target_by_id = {str(item.get("section_id")): item for item in artifact.get("target_sections") or []}
        if set(candidates) != set(target_by_id):
            raise RuntimeStoreError("全文初稿候选覆盖与目标章节不一致")
        unresolved = [
            section_id
            for section_id, candidate in candidates.items()
            if candidate.get("content_status", "complete") != "complete"
        ]
        if unresolved:
            raise RuntimeStoreError(
                f"仍有 {len(unresolved)} 个章节存在待决定或来源缺口，全文初稿未写入"
            )
        required_review_ids = {
            section_id
            for section_id, candidate in candidates.items()
            if candidate.get("review_level") == "required"
        }
        missing_confirmations = sorted(
            required_review_ids.difference(
                str(item) for item in confirmed_section_ids if str(item).strip()
            )
        )
        if missing_confirmations:
            raise RuntimeStoreError(
                f"仍有 {len(missing_confirmations)} 个高影响章节未逐卡确认，全文初稿未写入"
            )
        adopted: list[str] = []
        replayed: list[str] = []
        for section_id, target in target_by_id.items():
            candidate = candidates[section_id]
            proposal = _text(candidate.get("proposal_text"))
            if (
                len(proposal) < FULL_DRAFT_MINIMUM_BODY_CHARS
                or _PLACEHOLDER_RE.search(proposal)
                or INTERNAL_TRANSPORT_VOCABULARY_RE.search(proposal)
                or DRAFTING_PROCESS_VOCABULARY_RE.search(proposal)
                or next(iter_unresolved_draft_markers(proposal), None)
            ):
                raise RuntimeStoreError(f"全文初稿章节候选不具备实质内容：{section_id}")
            current = repo.working_copy(project_id, section_id)
            blocks = [dict(block) for block in current.content_blocks]
            body_index = next(
                (index for index, block in enumerate(blocks) if str(block.get("block_id")) == str(target.get("body_block_id"))),
                None,
            )
            if body_index is None:
                raise RuntimeStoreError(f"全文初稿目标正文块不存在：{section_id}")
            current_text = _text(blocks[body_index].get("text"))
            if current_text == proposal:
                replayed.append(section_id)
                continue
            if current.revision != int(target.get("expected_revision") or 0):
                raise StaleRuntimeStateError(f"全文初稿采纳遇到章节版本变化：{section_id}")
            if hashlib.sha256(current_text.encode("utf-8")).hexdigest() != str(target.get("body_sha256") or ""):
                raise StaleRuntimeStateError(f"全文初稿采纳遇到正文变化：{section_id}")
            blocks[body_index]["text"] = proposal
            expected_next_revision = current.revision + 1
            saved = repo.save_working_copy(
                project_id,
                section_id,
                MedicalWritingWorkingCopySaveRequest(
                    document_id=document.document_id,
                    expected_revision=current.revision,
                    content_blocks=blocks,
                    actor=actor,
                    idempotency_key=f"full-draft-adopt:{job.job_id}:{section_id}",
                ),
            )
            if saved.revision != expected_next_revision:
                raise RuntimeStoreError(f"全文初稿采纳未形成预期章节版本：{section_id}")
            adopted.append(section_id)
        return {
            "job_id": job.job_id,
            "project_id": project_id,
            "artifact_schema": FULL_DRAFT_ARTIFACT_SCHEMA,
            "adopted_section_ids": adopted,
            "replayed_section_ids": replayed,
            "adopted_count": len(adopted),
            "replayed_count": len(replayed),
            "coverage": artifact.get("coverage") or {},
        }

    def resolve_decision(
        self,
        project_id: str,
        durable_store: DurableJobStore,
        job: Any,
        *,
        decisions: Iterable[Mapping[str, Any]],
        idempotency_key: str,
        actor: str = "medical_manager",
        study_definition_writer: Optional[Callable[..., Any]] = None,
    ) -> dict[str, Any]:
        """Resolve full-draft decision cards in one explicit confirmation.

        The answer is written by the existing authoritative StudyDefinition
        confirmation channel handed in as ``study_definition_writer``; this
        service never invents a fact path and never keeps a decision store of
        its own.  A decision item that does not carry an already supported
        authoritative fact path fails closed.

        Resolution order matters and is preserved:

        1. validate every decision against the current immutable artifact;
        2. persist the confirmed answers through the existing channel (CAS plus
           audit live inside that channel);
        3. the persisted StudyDefinition revision invalidates this artifact
           under the existing ``adopt`` binding check — the artifact is never
           rewritten;
        4. submit a new full-draft job scoped to the affected sections only.
        """
        artifact = self.read_artifact(project_id, job)
        if artifact.get("schema_version") != FULL_DRAFT_ARTIFACT_SCHEMA:
            raise RuntimeStoreError(
                "旧版全文初稿候选仅供查阅；请按当前研究事实重新生成后再确认决定"
            )
        service = self._service(project_id)
        repo = service.repo
        document = repo.protocol(project_id)
        if str(document.document_id) != str(artifact.get("document_id")) or str(
            document.version
        ) != str(artifact.get("document_version")):
            raise StaleRuntimeStateError("全文初稿所属文档已变化，决定未写入")
        if self._binding(repo, project_id, document) != artifact.get("study_definition"):
            # The existing binding check already superseded this artifact.
            raise StaleRuntimeStateError("研究设计绑定已变化，本次决定未写入")
        key = _text(idempotency_key)
        if not key:
            raise ValueError("全文初稿决定确认需要 idempotency_key")
        index = self.decision_index(artifact)
        writer = study_definition_writer
        if writer is None or not callable(writer):
            raise RuntimeStoreError(
                "全文初稿决定尚未绑定研究设计确认通道，未写入任何研究事实"
            )
        submitted = list(decisions)
        if len(submitted) != 1:
            raise ValueError("每次只能确认一个全文初稿决定")
        resolved: list[dict[str, Any]] = []
        seen: set[str] = set()
        for raw in submitted:
            if not isinstance(raw, Mapping):
                raise ValueError("全文初稿决定必须是对象")
            decision_id = _text(raw.get("decision_id"))
            option_id = _text(raw.get("option_id"))
            if not decision_id or not option_id:
                raise ValueError("全文初稿决定需要 decision_id 与 option_id")
            if decision_id in seen:
                raise ValueError(f"全文初稿决定重复提交：{decision_id}")
            seen.add(decision_id)
            entry = index.get(decision_id)
            if entry is None:
                raise RuntimeStoreError(f"全文初稿候选不存在该决定项：{decision_id}")
            if entry["content_status"] != "decision_required":
                raise RuntimeStoreError(
                    f"该章节当前不是待决定状态，不能按决定项确认：{entry['section_id']}"
                )
            item = entry["item"]
            option = next(
                (
                    candidate
                    for candidate in item.get("options") or []
                    if _text(candidate.get("option_id")) == option_id
                ),
                None,
            )
            if option is None:
                raise RuntimeStoreError(
                    f"全文初稿决定项没有该选项：{decision_id}/{option_id}"
                )
            fact_path = _text(item.get("fact_path"))
            if not fact_path:
                raise RuntimeStoreError(
                    "决定项未绑定研究设计字段路径，无法写入权威研究设计；"
                    "请先在既有研究设计流程中确认该决定"
                )
            if fact_path not in SUPPORTED_ADOPT_PATHS:
                raise RuntimeStoreError(
                    f"决定项目标不是既有研究设计字段：{fact_path}"
                )
            if fact_path in _DECISION_STRUCTURED_DESIGN_PATHS:
                raise RuntimeStoreError(
                    f"决定项目标路径需要结构化设计取值，决定卡无法安全写入：{fact_path}；"
                    "请在研究设计中直接确认该决定"
                )
            if (artifact.get("decision_path_owners") or {}).get(fact_path) != entry["section_id"]:
                raise RuntimeStoreError(
                    f"决定项不属于该研究字段的指定章节：{fact_path}"
                )
            if fact_path not in self._available_decision_paths(service, project_id):
                raise StaleRuntimeStateError(
                    f"研究设计字段已确认或不再待决定：{fact_path}；请刷新全文初稿"
                )
            prose = _text(option.get("summary")) or _text(option.get("label"))
            resolved.append(
                {
                    "decision_id": decision_id,
                    "section_id": entry["section_id"],
                    "question": _text(item.get("question")),
                    "option_id": option_id,
                    "recommended_option_id": _text(item.get("recommended_option_id")),
                    "fact_path": fact_path,
                    "value": self._decision_fact_value(fact_path, prose),
                }
            )
        if not resolved:
            raise ValueError("全文初稿决定确认为空")

        confirmations: list[dict[str, Any]] = []
        for entry in resolved:
            value = entry["value"]
            if not value:
                raise RuntimeStoreError(
                    f"决定项选项缺少可写入的实质内容：{entry['decision_id']}"
                )
            outcome = writer(
                project_id,
                field_path=entry["fact_path"],
                value=value,
                actor=actor,
                idempotency_key=f"full-draft-decision:{job.job_id}:{entry['decision_id']}:{key}",
            )
            confirmations.append(
                {
                    "decision_id": entry["decision_id"],
                    "section_id": entry["section_id"],
                    "fact_path": entry["fact_path"],
                    "option_id": entry["option_id"],
                    "study_definition_revision": getattr(
                        getattr(outcome, "study_definition", None), "revision", None
                    ),
                    "journey_revision": getattr(outcome, "revision", None),
                }
            )

        affected_section_ids = sorted(
            {entry["section_id"] for entry in resolved}
        )
        regenerated_job_id, reused = self.submit_durable(
            project_id,
            durable_store,
            actor=actor,
            section_ids=affected_section_ids,
        )
        return {
            "job_id": job.job_id,
            "project_id": project_id,
            "artifact_schema": FULL_DRAFT_ARTIFACT_SCHEMA,
            "superseded_job_id": job.job_id,
            "resolved_decisions": resolved,
            "study_definition_confirmations": confirmations,
            "affected_section_ids": affected_section_ids,
            "regeneration": {
                "job_id": regenerated_job_id,
                "reused": bool(reused),
                "section_ids": affected_section_ids,
            },
        }
